import itertools
#O= ["U R U R' F' R U R' U' R' F R2 U' R'/R' U L' U2 R U' R' U2 R2 x'/U R U R' U' R' F R2 U' R' U' R U R' F'/U r U R' F' R U R' U' R' F R2 U' r'","F R U' R' U' R U R' F' R U R' U' R' F R F'/R' U L' U2 R U' x' U L' U2 R U' R x'/r' U' r' D' r U' r' D r U r' D' r U r' D r2/R2 D r' U r D' R2 U' F' U' F"]
#AS= ["R' U' R U' R' U2 R/U R U2 R' U' R U' R'/U2 L' U' L U' L' U2 L/U' L U2 L' U' L U' L'","U2 R2 D R' U R D' R' U R' U' R U' R'/U2 l' U R U' L2 U2 R' U R U2 L2 x'/U R' U' R U' R' U R' D' R U R' D R2/U L F2 L2 U2 L F' L' U2 L2 F2 L'","U2 F' L F L' U2 L' U2 L/U2 F' r U r' U2 r' F2 r/U' x' F U' R U L' U2 R' U2 R/U2 F' r U r' U2 L' U2 L","U2 R U2 R' U2 R' F R F'/L U2 L' U2 r' U L U' x/U2 R U2 R' U2 r' F R F' M'/U2 r U2 r' U2 R' F R F'","U2 L' U R U' L U R'/R' U L U' R U L'/U2 R' F R F' r U r'","R U R' F' R U2 R' U' R U' R' F R U' R'/R U2 R' F R' F' R U' R U' R'/U2 R' U' R U' L U' R' U L' U2 R/U2 R' U' R U' l U' R' U l' U2 R"]
#S= ["R U R' U R U2 R'/r U R' U R U2 r'/U' R' U2 R U R' U R/R U R' U r U2 r'","L' U2 L U2 L F' L' F/r' F2 r U2 r U' r' F/R' F2 R U2 R U' L' U x'/R' F2 R U2 r U' r' F","F R' F' R U2 R U2 R'/x U R' U' L U2 R U2 R'/F R' F' R U2 r U2 r'","U' R U R' U R U' R D R' U' R D' R2/r U' L' U R2 U2 L U' L' U2 R2 x'/U l U' R' U2 R' D R U2 R' D' R2 U l'/U2 R2 D' R U' R' D R U' R U R' U R","R U' L' U R' U' L/L F' L' F l' U' l","U2 R U R' U R' F R F' R U2 R'/U2 R U R' U L' U R U' L U2 R'/U2 R U R' F' R U R' U R U2 R' F R U' R'/R' U2 l U' R U l' U R' U R"]
#L= ["U' R U2 R' U' R U R' U' R U R' U' R U' R'/U R U2 R' U' R U' R' U2 R U R' U R U2 R'/U2 R' U' R U' R' U R U' R' U R U' R' U2 R/U R U R' U R U2 R' U R' U' R U' R' U2 R","R' U2 R' D' R U2 R' D R2/U2 L' U2 L' D' L U2 L' D L2/U2 R' F2 R' U' R F2 R' U R2/U2 F U2 F' U' R' F' R U' R' F' R","U R U2 R D R' U2 R D' R2/R' F' R U R' U' R' F R2 U' R' U2 R/U R' U' R U2 L' U R' U' L U' R/U' l U R' D R U2 R' D' R U l'","U F R' F' R U R U' R'/U' L' U' L' U R U' L U x'/l U' R' D R U R' D' x/U2 r U' L' D L U r' B'","U F R U' R' U' R U R' F'/U l' U R D' R' U' l B/U2 F' r U R' U' r' F R/U' x L' D L U' L' D' L U x'","U R U2 R2 F R F' R U2 R'/U r U2 R2 F R F' R U2 r'/U' L' U2 R U' r' U2 R l U' R'/U' R' U' R U R' F' R U R' U' R' F R2"]
#U= ["R' U' R U' R' U2 R2 U R' U R U2 R'/U' F2 R U' R' U R U R2 F' R F'/R2 F U' F U F2 R2 U' R' F R/r' U' R U' R' U2 R2 U R' U R U2 r'","U' F R2 D R' U R D' R2' U' F'/U' L U' R' U L' U2 F' U F R/U R' U L U' R U2 F U' F' L'/R' F R U' R' U' R U R' F' R U R' U' R' F R F' R","U2 R2 D R' U2 R D' R' U2 R'/L F' L' U' L F' L' U' F' U2 F/r U' r' U' r U' r' U' F' U2 F","U2 R' F2 R U2 R U2 R' F2 R U2 R'/U2 R' F U' R F R' U R F'/U' l U R' D R U' x U R' U' F'/U' R' D R U' R U' R' U R' D' R","R2 D' R U2 R' D R U2 R/R' F R U R' F R U F U2 F'","U' F R U R' U' F'/U F U R U' R' F'/U2 R' U' F' U F R"]
#T= ["R U2 R' U' R U' R2' U2' R U R' U R/F R' F R2 U' R' U' R U R' F2/r U2 R' U' R U' r2 U2 R U R' U r/U2 R' U2 R2 B2 D B D' B R2 U2 R","R' U r U2 R2' F R F' r/R' U r U2 R2' F R F' R/r' U r U2' R2' F R F' R/r' U r' U2 l U' l' U2 r2 B'","U L' U' L U L F' L' F/U r' F' r U r U' r' F/U R' F' r U R U' r' F/U' R' U' R U L U' R' U x","U2 F R U R' U' R U' R' U' R U R' F'/F R' U' R F' R' U F' R/U R U2 R' F2 R U2 R' U2 R' F2 R/U R' D R U' R U R' U R' D' R","U' R U R' U' R' F R F'/R U R D R' U' R D' R2/U' r U R' U' L' U l F'","R' U R2 D r' U2 r D' R2' U' R/R2' U' R F R' U R2 U' R' F' R/U2 r2 D' r U r' D r2 U' r' U' r/U2 R2 U R' B' R U' R2 U R B R'"]
#PI= ["F R U R' U' R U R' U' F'/R U2 R2' U' R2 U' R2' U2 R/f R U R' U' R U R' U' f'/U2 F' L' U' L U L' U' L U F","l U R' D R U' R U' R2' D' R U l'/U F R' F' R U2 R U' R' U R U2 R'/R' U' R U' R' U2 R U' L' U R U' L U R'/U F U R U' R2 F' R U2 R U2 R'","U' R' F R U F U' R U R' U' F'/U2 F U' F' U R' F2 R U2 R' F R/L' U2 y R U2 R' U2 R' U2 F y x/U2 F R' F' R U2 F R' F' R2 U2 R'","R U2 R' U' R U R' U2 R' F R F'/R U2' R' U2 R' F R2 U R' U' F'/R U R' U R U2 R' U' R U' L' U R' U' L/U F' U' L' U L2 F L' U2 L' U2 L","U2 L' U R U' L U' R' U' R U' R'/U2 R' F R F' r U' R' U' R U' r'/U2 r' F R F' r U' R' U' R U' R'/R' U L U' R U' L' U' L U' L'","U2 R' U' R U' R' U F' U F R/U' R' U' R' F R F' R U' R' U2 R/U2 R U R' U R U' y R U' R' y L'"]
#H= ["R U2 R' U' R U R' U' R U' R'/U' R' U' R U' R' U R U' R' U2 R/R' F R U R' F R U' R' F' R/L' U2 L U L' U' L U L' U L","U' R U R' U R U L' U R' U' L/U' R U R' U R U r' F R' F' r/U' r U R' U R U r' F R' F' R/U' R' F' R U2 R U2 R' F U' R U' R'","U R U2 R2 F R F' U2 R' F R F'/U2 R' F' R U2 R' F2 R U' F U F'/U R U2 R2 U' R U' R' U2 F R F'/R' F2 D R2 U R2 D' F2 R","F R U R' U' R U R' U' R U R' U' F'/F U R U' R' U R U' R' U R U' R' F'/F' L' U' L U L' U' L U L' U' L U F/F' U' L' U L U' L' U L U' L' U L F"]

#O= ["R U R' F' R U R' U' R' F R2 U' R'","F R U' R' U' R U R' F' R U R' U' R' F R F'"]
#H= ["R U2 R' U' R U R' U' R U' R'","F R U R' U' R U R' U' R U R' U' F'","(U) R U2' R2' F R F' U2 R' F R F'","(U2) r U' r2' D' r U' r' D r2 U r'"]
#PI=["F R U R' U' R U R' U' F'","(U) F R' F' R U2 R U' R' U R U2' R'","(U') R' F R U F U' R U R' U' F'","R U2 R' U' R U R' U2' R' F R F'    ","(U') r U' r2' D' r U r' D r2 U r'","(U') R' U' R' F R F' R U' R' U2 R"]
#U= ["(U2) R2 D R' U2 R D' R' U2 R'","R2' D' R U2 R' D R U2 R","R2' F U' F U F2 R2 U' R' F R","(U') F R2 D R' U R D' R2' U' F'","(U2) r U' r' U r' D' r U' r' D r","(U') F R U R' U' F'"]
#T= ["(U') R U R' U' R' F R F'","(U) L' U' L U L F' L' F","F R' F R2 U' R' U' R U R' F2","r' U r U2' R2' F R F' R","r' D' r U r' D r U' r U r'","(U2) r2' D' r U r' D r2 U' r' U' r"]
#S= ["(U) R U R' U R U2 R'","(U) L' U2 L U2' L F' L' F","(U) F R' F' R U2 R U2' R'  ","(U2) R' U' R U' R2' F' R U R U' R' F U2' R","(U') R U R' U R' F R F' R U2' R'","(U) R U' L' U R' U' L"]
#AS=["(U) R' U' R U' R' U2' R","(U') R2 D R' U R D' R' U R' U' R U' R'","(U') F' L F L' U2' L' U2 L   ","(U') R U2' R' U2 R' F R F'","(U') L' U R U' L U R'","R' U' R U' R' U R' F R F' U R"]
#L= ["(U2) F R U' R' U' R U R' F'","(U2) F R' F' R U R U' R'","R U2 R' U' R U R' U' R U R' U' R U' R'","(U2) R U2 R D R' U2 R D' R2' ","R' U' R U R' F' R U R' U' R' F R2","(U) R' U2 R' D' R U2 R' D R2"]

O=  ["R U R' F' R U R' U' R' F R2 U' R'","F R U' R' U' R U R' F' R U R' U' R' F R F'"]
H= ["R U R' U R U2' R' ","R U' L' U R' U' L ","U2' R' U' R U' R2' D' R U2 R' D R2 ","U' R U R' U R U' R D R' U' R D' R2' ","R2' F R U R U' R' F' R U' R' U R ","U2' R U R' F' R U R' U R U2' R' F R U' R' "]
PI=["R' U' R U' R' U2 R ","U2' L' U R U' L U R' ","U2' R' U' R U' R2' D' R U2 R' D R2 ","R U R' F' R U2 R' U' R U' R' F R U' R' ","R U R' F' R U2 R' U2' R' F R2 U' R' ","U R' U' R U' R' U R' D' R U R' D R2 "]
U= ["R U R' U R U' R' U R U' R' U R U2' R' ","U' R U2' R D R' U2 R D' R2' ","U' F R' F' r U R U' r' ","R' U' R U R' F' R U R' U' R' F R2 ","U2 R' U2' R' D' R U2 R' D R2 ","F' r U R' U' r' F R "]
T= ["R U2' R' U' R U' R2' U2' R U R' U R ","R' U R U2' L' R' U R U' L ","U (l' U' L U) (R U' r' F) ","U2 F R U R' U' R U' R' U' R U R' F'","R U R' U' R2 D R' U2 R D' R2' U R U' R'","U' (r U R' U') (r' F R F')"]
S= ["U2' R U R' U R U2' R2' U' R U' R' U2 R ","U2' R 2 D R' U2 R D' R' U2 R' ","R' F R U' R' U' R U R' F' R U R' U' R' F R F' R ","F R U' R' U R U R' U R U' R' F'","R2' D' R U2 R' D R U2 R ","R2' D' R U R' D R U R U' R' U' R "]
AS=["R U2' R2' U' R2 U' R2' U2' R ","U' R' U' R U' R' U R U' R' U R' D' R U R' D R2 ","U' R U R' U F' R U2 R' U2' R' F R ","U R U2 R' U' F' R U2 R' U' R U' R' F R U' R'","R U R' U' R' F R2 U R' U' R U R' U' F'","R' U' F' R U R' U' R' F R2 U2' R' U2 R"]
L= ["R' U' R U' R' U R U' R' U2 R ","F R U' R' U R U2 R' U' R U R' U' F'","F R U R' U' R U R' U' R U R' U' F'","R' F' R U2 R U2' R' F U' R U' R'"]

moves = ["", "U", "U'", "U2"]

combos = list(itertools.product(moves, moves))


def one_alg(combo, alt_str):
    alt_list = alt_str.split("/")
    
    arr = []
    for alg in alt_list:
        arr.append("R" + combo[0] + "(" + alg.replace("(", "").replace(")", "") + ")" + combo[1] + "R'")
    return "/".join(arr)

def biglist(lis):
    result_arr = []
    for alt_str in lis:
        for combo in combos:
            result_arr.append(one_alg(combo, alt_str))
    return result_arr

def parse_set(lis, name):
    return '"' + name + '"'  + ":" +  str(biglist(lis)) + ","


print("\n   _____ _______       _____ _______ \n  / ____|__   __|/\   |  __ \__   __|\n | (___    | |  /  \  | |__) | | |   \n  \___ \   | | / /\ \ |  _  /  | |   \n  ____) |  | |/ ____ \| | \ \  | |   \n |_____/   |_/_/    \_\_|  \_\ |_|   \n                                     \n                                     \n")
print(parse_set(O, "O"))
print(parse_set(AS, "AS"))
print(parse_set(S, "S"))
print(parse_set(L, "L"))
print(parse_set(U, "U"))
print(parse_set(T, "T"))
print(parse_set(PI, "PI"))
print(parse_set(H, "H"))
